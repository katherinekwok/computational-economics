halton(const aU,const dim,const grid);
