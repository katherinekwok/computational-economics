transform(aFunc,aDFunc,const vX, const bound, const a, const b);
