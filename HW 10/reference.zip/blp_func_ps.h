ivreg(const mY,const mVariables,const mInstruments,const mWeight) ;
transform(const aParam,const aDParam,const vP);
value(const aMu,const vParam,const t);
demand(const mMu,const aShare,const aJac,const vDelta,const t,const vParam);
jacobian(const aJacobian,const vDelta,const vP);
inverse(const aDelta, const vP,const eps1,const eps);
gmm_obj(const vP, const adFunc, const avScore, const amHessian);
